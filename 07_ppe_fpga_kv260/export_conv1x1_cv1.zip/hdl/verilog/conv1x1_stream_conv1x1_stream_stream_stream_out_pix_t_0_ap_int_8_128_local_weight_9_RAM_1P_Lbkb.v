// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Version: 2022.2
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
`timescale 1 ns / 1 ps
module conv1x1_stream_conv1x1_stream_stream_stream_out_pix_t_0_ap_int_8_128_local_weight_9_RAM_1P_Lbkb (
     
    address0, ce0,
    d0, we0, 
    q0, 
     
    reset, clk);

parameter DataWidth = 8;
parameter AddressWidth = 7;
parameter AddressRange = 128;
 
input[AddressWidth-1:0] address0;
input ce0;
input[DataWidth-1:0] d0;
input we0; 
output reg[DataWidth-1:0] q0; 

input reset;
input clk;

(* ram_style = "distributed"  *)reg [DataWidth-1:0] ram[0:AddressRange-1];

initial begin
    $readmemh("./conv1x1_stream_conv1x1_stream_stream_stream_out_pix_t_0_ap_int_8_128_local_weight_9_RAM_1P_Lbkb.dat", ram);
end 

 





//read first
always @(posedge clk)  
begin 
    if (ce0) begin
        if (we0) 
            ram[address0] <= d0; 
        q0 <= ram[address0];

    end
end 
 
 

endmodule

